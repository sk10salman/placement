#include <bits/stdc++.h>
#include<fstream>
using namespace std;

int main()
{
string s;
cout<<"enter keyword : ";
getline(cin,s);
int arr[26]={0};
char key[25];
int k=0;
for(int i=0;i<s.length();i++){
    if(s[i]=='j'){
        int x1='i'-'a';
        if(arr[x1]==0){
            key[k]=char(x1+97);
            k++;
            arr[x1]=1;
        }
    }
    else{
        int x1=s[i]-'a';
        if(arr[x1]==0){
            key[k]=char(x1+97);
            k++;
            arr[x1]=1;
        }
    }
}
for(int i=0;i<9;i++){
    if(arr[i]==0){
        key[k]=char(i+97);
        k++;
        arr[i]=1;
    }
}
for(int i=10;i<26;i++){
    if(arr[i]==0){
        key[k]=char(i+97);
        k++;
        arr[i]=1;
    }
}
char key1[5][5];
k=0;
for(int i=0;i<5;i++){
    for(int j=0;j<5;j++){
        key1[i][j]=key[k];
        k++;
    }
}
cout<<"enter plain text : ";
string text;
getline(cin,text);
vector<char> v1;
for(int i=0;i<text.length();i++){
    if(i==0){
        v1.push_back(text[i]);
    }
    else{
        if(text[i]==v1.back() && v1.size()%2==1){
            v1.push_back('x');
            v1.push_back(text[i]);
        }
        else{
            v1.push_back(text[i]);
        }
    }
}


if(v1.size()%2==1){
    v1.push_back('x');
}

k=0;
int r1,c1,r2,c2;
int br=0;
string ct="";
vector<char> v2;
while(k<v1.size()){
int r1,c1,r2,c2;
br=0;
for(int i=0;i<5;i++){
    for(int j=0;j<5;j++){
        if(key1[i][j]==v1[k]){
            r1=i;
            c1=j;
            br=1;
            break;
        }
    }
    if(br==1){
        break;
    }
}
br=0;
k++;
for(int i=0;i<5;i++){
    for(int j=0;j<5;j++){
        if(key1[i][j]==v1[k]){
            r2=i;
            c2=j;
            br=1;
            break;
        }
    }
    if(br==1){
        break;
    }
}
k++;
if(r1==r2){
    ct=ct+key1[r1][(c1+1)%5];
    v2.push_back(key1[r1][(c1+1)%5]);
    ct=ct+key1[r2][(c2+1)%5];
    v2.push_back(key1[r2][(c2+1)%5]);
}
else if(c1==c2){
    ct=ct+key1[(r1+1)%5][c1];
    v2.push_back(key1[(r1+1)%5][c1]);
    ct=ct+key1[(r2+1)%5][c2];
    v2.push_back(key1[(r2+1)%5][c2]);
}
else{
    ct=ct+key1[r1][c2];
    v2.push_back(key1[r1][c2]);
    ct=ct+key1[r2][c1];
    v2.push_back(key1[r2][c1]);
}
}
cout<<"cipher text is : "<<ct<<"\n";

k=0;
string pt="";
while(k<v2.size()){
int r1,c1,r2,c2;
br=0;
for(int i=0;i<5;i++){
    for(int j=0;j<5;j++){
        if(key1[i][j]==v2[k]){
            r1=i;
            c1=j;
            br=1;
            break;
        }
    }
    if(br==1){
        break;
    }
}
br=0;
k++;
for(int i=0;i<5;i++){
    for(int j=0;j<5;j++){
        if(key1[i][j]==v2[k]){
            r2=i;
            c2=j;
            br=1;
            break;
        }
    }
    if(br==1){
        break;
    }
}
k++;
if(r1==r2){
    pt=pt+key1[r1][(c1-1)%5];
    pt=pt+key1[r2][(c2-1)%5];
}
else if(c1==c2){
    pt=pt+key1[(r1-1)%5][c1];
    pt=pt+key1[(r2-1)%5][c2];
}
else{
    pt=pt+key1[r1][c2];
    pt=pt+key1[r2][c1];
}
}
cout<<"plain text : "<<pt<<"\n";
return 0;
}

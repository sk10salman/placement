#include <iostream>
#include<bits/stdc++.h>
using namespace std;

int main()
{
string text;
cout<<"\nenter the text to encrypt : ";
getline(cin,text);
string key;
cout<<"\nenter the key : ";
getline(cin,key);


int i;
string ciphertext="";
for(i=0;i<text.length();i++){
    int x1=((text[i]-'a')+(key[i%(key.length())]-'a'))%26;
    char ch=char(97+x1);
    ciphertext=ciphertext+ch;
}
cout<<"cipher text generated is : "<<ciphertext<<"\n";


string plaintext="";
for(i=0;i<ciphertext.length();i++){
    int x1=((ciphertext[i]-'a')-(key[i%(key.length())]-'a')+26)%26;
    char ch=char(97+x1);
    plaintext=plaintext+ch;
}
cout<<"plain text generated from cipher text is : "<<plaintext<<"\n";

return 0;
}

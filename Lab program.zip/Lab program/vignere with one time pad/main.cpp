#include <iostream>
#include<bits/stdc++.h>
using namespace std;

int main()
{
string text;
cout<<"\nenter the text to encrypt : ";
getline(cin,text);
int i;
string key="";
for(i=0;i<text.length();i++){
    int x1=rand()%26;
    key=key+char(97+x1);
}
cout<<"random key generated is : "<<key<<"\n";
string ciphertext="";
for(i=0;i<text.length();i++){
    int x1=((text[i]-'a')+(key[i]-'a'))%26;
    ciphertext=ciphertext+char(97+x1);
}
cout<<"cipher text generated is : "<<ciphertext<<"\n";


string plaintext="";
for(i=0;i<ciphertext.length();i++){
    int x1=((ciphertext[i]-'a')-(key[i]-'a')+26)%26;
    plaintext=plaintext+char(97+x1);
}
cout<<"plain text generated from cipher text is : "<<plaintext<<"\n";


return 0;
}

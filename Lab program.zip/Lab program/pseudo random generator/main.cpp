#include <iostream>
#include<bits/stdc++.h>
using namespace std;

int main()
{
srand(time(0));
cout<<"random number generated : "<<rand()<<"\n";
return 0;
}

#include <bits/stdc++.h>
using namespace std;
long long int m=1000000007;

int fun1(int a, int b)
{
    if (b == 0)
        return a;
    return fun1(b, a % b);

}

int main()
{
int arr[2][2];

cout<<"\nenter the key of 2X2 matrix : ";
for(int i=0;i<2;i++){
    for(int j=0;j<2;j++){
        cin>>arr[i][j];
        getchar();
    }
}


int det=arr[0][0]*arr[1][1]-arr[0][1]*arr[1][0];
int gcd=0;
while(det==0 || gcd!=1){
    cout<<"with this array encryption is not possible\nenter array again : ";
    for(int i=0;i<2;i++){
        for(int j=0;j<2;j++){
            cin>>arr[i][j];
            getchar();
        }
    }
    det=arr[0][0]*arr[1][1]-arr[0][1]*arr[1][0];
    if(det>=0){
        det=det%26;
    }
    else{
        det=((abs(det))/26)*26+26+det;
    }
    gcd=fun1(det,26);
}


string text;
cout<<"\nenter the text to encrypt : ";
getline(cin,text);
if(text.length()%2==1){
    text=text+'x';
}


int i=0;
int arrp[2];
string ciphertext="";
while(i<text.length()){
    arrp[0]=text[i]-'a';
    arrp[1]=text[i+1]-'a';
    i=i+2;
    for(int p=0;p<2;p++){
        int sum=0;
        for(int q=0;q<2;q++){
            sum=sum+arrp[q]*arr[q][p];
        }
        if(sum>=0){
            sum=sum%26;
        }
        else{
            sum=((abs(sum))/26)*26+26+sum;
        }
        char ch=char(sum+97);
        ciphertext=ciphertext+ch;
    }

}
cout<<"cipher text generated is : "<<ciphertext<<"\n";




for(int i=1;i<m;i++){
    if((det*i)%26==1){
        det=i;
        break;
    }
}


int t=arr[0][0];
arr[0][0]=arr[1][1];
arr[1][1]=t;
t=arr[0][1];
arr[0][1]=arr[1][0];
arr[1][0]=t;


int adj[2][2];
for(int p=0;p<2;p++){
    for(int q=0;q<2;q++){
        adj[p][q]=arr[q][p];
    }
}


for(int p=0;p<2;p++){
    for(int q=0;q<2;q++){
        adj[p][q]=det*adj[p][q];
        if((p+q)%2==1){
            adj[p][q]=adj[p][q]*(-1);
        }
        if(adj[p][q]>=0){
            adj[p][q]=adj[p][q]%26;
        }
        else{
            adj[p][q]=((abs(adj[p][q]))/26)*26+26+adj[p][q];
        }
    }
}


i=0;
string plaintext="";
while(i<ciphertext.length()){
    arrp[0]=ciphertext[i]-'a';
    arrp[1]=ciphertext[i+1]-'a';
    i=i+2;
    for(int p=0;p<2;p++){
        int sum=0;
        for(int q=0;q<2;q++){
            sum=sum+arrp[q]*adj[q][p];
        }
        if(sum>=0){
            sum=sum%26;
        }
        else{
            sum=((abs(sum))/26)*26+26+sum;
        }
        char ch=char(sum+97);
        plaintext=plaintext+ch;
    }

}
cout<<"plain text generated from cipher text is : "<<plaintext<<"\n";


return 0;
}

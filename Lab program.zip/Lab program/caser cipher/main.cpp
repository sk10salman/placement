#include <bits/stdc++.h>
#include<fstream>
using namespace std;

int main()
{
/*
string s;
cout<<"enter the file name : ";
getline(cin,s);
ifstream fin(s.c_str());

ofstream fout("file2.txt");
char ch;

while(fin>>ch){
    fout<<ch;
}
fin.close();
fout.close();
*/
int n;
int key;
cout<<"press 1 to encrypt a file\npress 2 to decrypt a file\npress 0 to exit\n";
cin>>n;
getchar();
while(n!=0){
    if(n==1){
        cout<<"enter file name you want to encrypt : ";
        string s1;
        getline(cin,s1);
        cout<<"enter key : ";
        cin>>key;
        getchar();
        cout<<"enter file name you where want to write decrypted text : ";
        string s2;
        getline(cin,s2);
        ifstream fin(s1.c_str());
        ofstream fout(s2.c_str());
        char ch;
        while(fin>>ch){
            int x1=ch-'a';
            x1=x1+key;
            x1=(x1+26)%26;
            ch=char(97+x1);
            fout<<ch;
        }
        fin.close();
        fout.close();
    }
    else if(n==2){
        cout<<"enter file name you want to decrypt : ";
        string s1;
        getline(cin,s1);
        cout<<"enter key : ";
        cin>>key;
        getchar();
        cout<<"enter file name you where want to write original text : ";
        string s2;
        getline(cin,s2);
        ifstream fin(s1.c_str());
        ofstream fout(s2.c_str());
        char ch;
        while(fin>>ch){
            int x1=ch-'a';
            x1=x1-key;
            x1=(x1+26)%26;
            ch=char(97+x1);
            fout<<ch;
        }
        fin.close();
        fout.close();
    }

    cout<<"press 1 to encrypt a file\npress 2 to decrypt a file\npress 0 to exit\n";
    cin>>n;
    getchar();
}
return 0;
}

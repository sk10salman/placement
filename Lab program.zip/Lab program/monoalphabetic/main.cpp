#include <bits/stdc++.h>
#include<fstream>
using namespace std;

int main()
{
char key[26];
int arr[26]={0};
cout<<"entering key : \n";
char ch;
for(int i=0;i<26;i++){
    cout<<"enter alphabet with which "<<char(i+97)<<" will be substituted : ";
    cin>>ch;
    int x1=int(ch);
    //cout<<x1;
    while((x1<97 || x1>122) || arr[x1-'a']==1){
        cout<<"this value for "<<char(i+97)<<" is not valid . enter a valid character from a to z and which has yet not been entered : ";
        cin>>ch;
        x1=int(ch);
    }
    key[i]=ch;
    arr[x1-'a']=1;
}
char dkey[26];
for(int i=0;i<26;i++){
    dkey[key[i]-'a']=char(i+97);
}
int n;
cout<<"press 1 to encrypt a file\npress 2 to decrypt a file\npress 0 to exit\n";
cin>>n;
getchar();
while(n!=0){
    if(n==1){
        cout<<"enter file name you want to encrypt : ";
        string s1;
        getline(cin,s1);
        cout<<"enter file name you where want to write decrypted text : ";
        string s2;
        getline(cin,s2);
        ifstream fin(s1.c_str());
        ofstream fout(s2.c_str());
        char ch;
        while(fin>>ch){
            fout<<key[ch-'a'];
        }
        fin.close();
        fout.close();
    }
    else if(n==2){
        cout<<"enter file name you want to decrypt : ";
        string s1;
        getline(cin,s1);
        cout<<"enter file name you where want to write original text : ";
        string s2;
        getline(cin,s2);
        ifstream fin(s1.c_str());
        ofstream fout(s2.c_str());
        char ch;
        while(fin>>ch){
            fout<<dkey[ch-'a'];
        }
        fin.close();
        fout.close();
    }

    cout<<"press 1 to encrypt a file\npress 2 to decrypt a file\npress 0 to exit\n";
    cin>>n;
    getchar();
}

return 0;
}
